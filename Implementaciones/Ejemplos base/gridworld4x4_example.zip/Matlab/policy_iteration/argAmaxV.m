function [ actmax_final ] = argAmaxV( gamma, p, r, v, s, num_a, order )
%ARGAMAXV Devuelve la acci�n a que maximiza la state-value function.
%   Evalua la state-value function del estado actual, s, de acuerdo a las
%   probabilidades de transici�n p, recompensas r y state-values v conocidos
%   de las iteraciones anteriores, para todas las accion posibles. Finalmente,
%   devuelve la acci�n que maximiza dicha funci�n para el estado actual s.
%   Input:
%       -gamma: discount rate
%       -p: matriz que contiene las probabilidades de transici�n, de acuerdo
%        a las relgas del juego.
%       -r: matriz que contiene las recompensas obtenidas, de acuerdo a las
%        normas del juego.
%       -v: vector que contiene los state-values actuales.
%       -s: estado en el cual se va a evaluar la state-value function.
%       -num_a: n�mero de acciones posibles.
%       -order: par�metro empleado para el tie-break. En caso de empate,
%        decide qu� acci�n tomar de entre todas las acciones que empatan.
%   Output:
%       -actmax_final: acci�n que maximiza la state-value function del estado
%        s.

v_aux = zeros(num_a, 1); % vector de v's auxiliar para cada acci�n
for a = 1:num_a
    % evaluamos la state-value function para cada acci�n posible
    v_aux(a) = squeeze(p(s,a,:))'*squeeze(r(s,a,:)) + squeeze(p(s,a,:))'*gamma*v;
end
% obtenemos la/las acci�n/acciones con la cual/las cuales se maximiza v:
m = max(v_aux); % conocemos el valor v m�ximo
% en caso de empate de acciones, buscamos todas aquellas que maximizan el state-value:
actmax_aux = find(v_aux == m); % vector con las acciones que empatan
actmax_final = actmax_aux(mod(order, size(actmax_aux,2))+1); % en caso de empate, elegir la acci�n n�mero "order"
% con mod(order, size(actmax_aux,2)) nos aseguramos de que si pedimos
% elegir la acci�n |order| y el |n�mero de acciones que empatan| < |order|,
% matlab no lance error, sino que coja la siguiente opci�n posible siguiendo
% aritm�tica modular.
% El +1 es necesario por la indexaci�n de matlab.
end

