% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Nombre del fichero: policy_iteration.m                  %
% Autor: Daniel M. Garc�a-Oca�a Hern�ndez                 %
% Fecha de creaci�n: 07/10/2016                           %
% Implementaci�n in-place del algoritmo policy iteration  %
% (p.85 de Reinforcement Learning: An Introduction)       %
% Ejemplo: gridworld 4x4, p.81 Example 4.1                %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

clear all, close all, clc

% dynamics_SxA define una matriz de transiciones en la que las filas son los
% estados s1:s15 y las columnas las acciones a1:a4 donde a1 = izquierda, a2 = arriba,
% a3 = derecha y a4 = abajo. El valor de cada elemento de de la matriz nos
% indica el n�mero de estado al que pasaremos al aplicar una determinada acci�n.
% As� por ejemplo, si estamos en el estado s1 (estado terminal), cualquier
% acci�n nos llevar� a �l mismo. Por el contrario, si estamos en el estado
% s3 y aplicamos la acci�n a4 (movernos abajo), pasaremos al estado s7 (6 + 1,
% por la indexaci�n de Matlab).
dynamics_SxA = [0 0 0 0 % 0 corresponde al estado terminal
    0 1 2 5;
    1 2 3 6;
    2 3 3 7;
    4 0 5 8;
    4 1 6 9;
    5 2 7 10;
    6 3 7 11;
    8 4 9 12;
    8 5 10 13;
    9 6 11 14;
    10 7 11 0
    12 8 13 12;
    12 9 14 13;
    13 10 0 14]+1; % +1 porque los �ndices en matlab empiezan en 1

numS = 15; % n�mero de estados posibles (14 + estado terminal = 15)
numA = 4; % n�mero de acciones posibles (izquierda, arriba, derecha, abajo)
gamma = 0.99; % discount rate

P = get_dynamics(numS, numA, dynamics_SxA); % p(s'|s,a)
policy = policy_initialization(numS, numA); % pi(a|s);
R = reward_initialization(numS, numA, dynamics_SxA); % r(s,a,s');
V = state_value_initializacion(numS); % v(s)

theta = 1e-4; % condici�n de convergencia
policy_stable = false; % flag used to point convergence of policy
while ~policy_stable % evaluar lo de dentro del bucle hasta que el algoritmo haya convergido
    % 2. Policy evaluation
    while true
        inc=0;
        for s = 1:numS
            v = V(s);
            V(s) = evalV(gamma, P, R, V, s, policy);
            inc = max(inc,abs(v-V(s)));
        end
        if inc < theta
            break
        end
    end
    
    % 3. Policy improvement
    policy_stable = true;
    for s = 1:numS
        a = policy(s);
        policy(s) = argAmaxV(gamma, P, R, V, s, numA, 0);
        if a~= policy(s) % si la policy vieja y la nueva son distintas, continuar con el bucle
            policy_stable = false;
        end
    end
end

V % mostramos por pantalla el valor final de la state-value function
figure, stem((1:numS),policy), xlim([1,numS]) % ploteamos la policy �ptima encontrada
xlabel('Casilla'), ylabel('Pol�tica final (movimiento)')
