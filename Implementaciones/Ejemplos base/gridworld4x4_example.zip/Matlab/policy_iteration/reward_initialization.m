function [ R ] = reward_initialization( num_s, num_a, dynamics_sxa )
%REWARD_INITIALIZATION Devuelve la matriz de recompensas del juego
%   Inicializa una matriz de dimensi�n (s x a x s') que contendr� la recompensa
%   obtenida al pasar a un estado s',desde un estado s conocido y tomando una
%   acci�n a conocida.
%   Input:
%       -num_s: n�mero de estados posibles.
%       -num_a: n�mero de acciones posibles.
%       -dynamics_sxa: matriz de transiciones con las reglas del juego. Nos
%        dice para un estado s, a qu� estados s' podemos saltar.
%   Output:
%       -R: matriz rellena con las recompensas obtenidas de acuerdo a las
%        normas del juego.

R = zeros(num_s, num_a, num_s);
for s = 1:num_s
    % la recompensa es -1 en todas las transiciones hasta que el estado terminal es alcanzado
    for a = 1:num_a
        % si s es distinto de 1 la transici�n ocurre desde un estado no terminal, y por tanto la recompensa es -1
        if s ~= 1
            R(s,a,dynamics_sxa(s,a)) = -1;
        end
    end
end
end

