function [ v_aux ] = evalV( gamma, p, r, v, s, policy )
%EVALV Devuelve el state-value del estado actual s.
%   Evalua la state-value function del estado actual, s, para la policy
%   actual, policy, y de acuerdo a las probabilidades de transici�n p,
%   recomensas r y state-values v conocidos de las iteraciones anteriores.
%   Input:
%       -gamma: discount rate
%       -p: matriz que contiene las probabilidades de transici�n, de acuerdo
%        a las relgas del juego.
%       -r: matriz que contiene las recompensas obtenidas, de acuerdo a las
%        normas del juego.
%       -v: vector que contiene los state-values actuales.
%       -s: estado en el cual se va a evaluar la state-value function.
%       -policy: policy a seguir en la evaluaci�n de la state-value function.
%   Output:
%       -v_aux: state-value asociado al estado s, siguiendo la policy
%        pasada por argumento

a = policy(s);
v_aux = squeeze(p(s,a,:))'*squeeze(r(s,a,:)) + squeeze(p(s,a,:))'*gamma*v;
end

