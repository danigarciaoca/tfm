function [ policy ] = policy_initialization( num_s, num_a )
%POLICY_INITIALIZATION Devuelve la pol�tica tomada inicialmente.
%   Inicializa un vector de dimensi�n (s) con una policy cualquiera siguiendo
%   las pautas que se deseen.
%   Input:
%       -num_s: n�mero de estados posibles.
%       -num_a: n�mero de acciones posibles.
%   Output:
%       -policy: vector relleno con la policy inicial deseada. Constituye el
%        mapeo inicial de estados a acciones.

% inicializa una policy equiprobable aleatoria
policy = randi([1 num_a],num_s,1);
end

