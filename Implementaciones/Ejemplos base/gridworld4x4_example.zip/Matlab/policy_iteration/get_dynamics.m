function [ P ] = get_dynamics( num_s, num_a, dynamics_sxa )
%GET_DYNAMICS Devuelve las dynamics del juego.
%   Inicializa una matriz de dimensi�n (s x a x s') que contendr� las probabilidades
%   de transici�n a un estado s', desde un estado s conocido y tomando una
%   acci�n a conocida.
%   Input:
%       -num_s: n�mero de estados posibles.
%       -num_a: n�mero de acciones posibles.
%       -dynamics_sxa: matriz de transiciones con las reglas del juego. Nos
%        dice para un estado s, a qu� estados s' podemos saltar.
%   Output:
%       -P: matriz rellena con las probabilidades de transici�n, de acuerdo
%        a las normas del juego.

P = zeros(num_s, num_a, num_s);
for s = 1:num_s
    for a = 1:num_a
        % establecemos a 1 la probabilidad de pasar al estado dynamics_sxa[s,a] cuando estamos en el
        % estado s y tomamos la acci�n a
        P(s,a,dynamics_sxa(s,a)) = 1;
    end
end
end

