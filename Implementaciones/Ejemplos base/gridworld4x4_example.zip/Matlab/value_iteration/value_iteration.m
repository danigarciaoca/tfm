% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Nombre del fichero: value_iteration.py                  %
% Autor: Daniel M. Garc�a-Oca�a Hern�ndez                 %
% Fecha de creaci�n: 07/10/2016                           %
% Implementaci�n in-place del algoritmo value iteration   %
% (p.88 de Reinforcement Learning: An Introduction)       %
% Ejemplo: gridworld 4x4, p.81 Example 4.1                %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

clear all, close all, clc

% dynamics_SxA define una matriz de transiciones en la que las filas son los
% estados s1:s15 y las columnas las acciones a1:a4 donde a1 = izquierda, a2 = arriba,
% a3 = derecha y a4 = abajo. El valor de cada elemento de de la matriz nos
% indica el n�mero de estado al que pasaremos al aplicar una determinada acci�n.
% As� por ejemplo, si estamos en el estado s1 (estado terminal), cualquier
% acci�n nos llevar� a �l mismo. Por el contrario, si estamos en el estado
% s3 y aplicamos la acci�n a4 (movernos abajo), pasaremos al estado s7 (6 + 1,
% por la indexaci�n de Matlab).
dynamics_SxA = [0 0 0 0 % 0 corresponde al estado terminal
    0 1 2 5;
    1 2 3 6;
    2 3 3 7;
    4 0 5 8;
    4 1 6 9;
    5 2 7 10;
    6 3 7 11;
    8 4 9 12;
    8 5 10 13;
    9 6 11 14;
    10 7 11 0
    12 8 13 12;
    12 9 14 13;
    13 10 0 14]+1; % +1 porque los �ndices en matlab empiezan en 1

numS = 15; % n�mero de estados posibles (14 + estado terminal = 15)
numA = 4; % n�mero de acciones posibles (izquierda, arriba, derecha, abajo)
gamma = 1; % discount rate

P = get_dynamics(numS, numA, dynamics_SxA); % p(s'|s,a)
policy = policy_initialization(numS, numA); % pi(a|s);
R = reward_initialization(numS, numA, dynamics_SxA); % r(s,a,s')
V = state_value_initializacion(numS); % v(s)

theta = 1e-4; % condici�n de convergencia
while true % evaluar lo de dentro del bucle hasta que el algoritmo haya convergido
    inc=0;
    for s = 1:numS
        v = V(s);
        V(s) = maxV(gamma, P, R, V, s, numA); % ecuaci�n de optimalidad de Bellman
        % buscamos de entre todos los estados, aquel cuya diferencia entre el state-value anterior y actual
        % es m�xima. Si se garantiza la convergencia para este estado, se garantiza para los dem�s por ser la
        % diferencia m�xima
        inc = max(inc,abs(v-V(s)));
    end
    if inc < theta
        % cuando el algoritmo ha convergido, paramos el bucle de value iteration
        break
    end
end

for s = 1:numS
    policy(s) = argAmaxV(gamma, P, R, V, s, numA, 0);
end

V % mostramos por pantalla el valor final de la state-value function
figure, stem((1:numS),policy), xlim([1,numS]) % ploteamos la policy �ptima encontrada
xlabel('Casilla'), ylabel('Pol�tica final (movimiento)')
