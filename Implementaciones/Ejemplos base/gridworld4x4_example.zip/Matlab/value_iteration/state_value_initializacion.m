function [ V ] = state_value_initializacion( num_s )
%STATE_VALUE_INITIALIZACION Devuelve los state-values iniciales
%   Inicializa un vector de dimensi�n (s) con unos state-values
%   cualesquiera.
%   Input:
%       -num_s: n�mero de estados posibles.
%   Output:
%       -V: vector relleno con los state-value de inicializaci�n. Se
%       incializar�n con un valor cualquiera.

V = zeros(num_s, 1); % inicializamos a cero los valores de la state-value function

end

