function [ v_final ] = maxV( gamma, p, r, v, s, num_a )
%MAXV Devuelve el m�ximo state-value del estado actual s.
%   Evalua la state-value function del estado actual, s, de acuerdo a las
%   probabilidades de transici�n p, recompensas r y state-values v conocidos
%   de las iteraciones anteriores, para todas las accion posibles. Finalmente,
%   devuelve state-value m�ximo.
%   Input:
%       -gamma: discount rate
%       -p: matriz que contiene las probabilidades de transici�n, de acuerdo
%        a las relgas del juego.
%       -r: matriz que contiene las recompensas obtenidas, de acuerdo a las
%        normas del juego.
%       -v: vector que contiene los state-values actuales.
%       -s: estado en el cual se va a evaluar la state-value function.
%       -num_a: n�mero de acciones posibles.
%   Output:
%       -v_final: state-value m�ximo para el estado actual s.

v_aux = zeros(num_a,1);
for a = 1:num_a
    % evaluamos la state-value function para todas las posibles acciones
    v_aux(a) = squeeze(p(s,a,:))'*squeeze(r(s,a,:)) + squeeze(p(s,a,:))'*gamma*v;
end
% seguimos aquella acci�n que maximiza la state-value function, lo cual se traduce en
% quedarnos el m�ximo valor de los state-values obtenidos (ecuaci�n de optimalidad de
% Bellman; seguimos una greedy policy respecto al valor de la state-value function)
v_final = max(v_aux);

end